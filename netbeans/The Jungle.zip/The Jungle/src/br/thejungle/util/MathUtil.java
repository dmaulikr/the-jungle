/*
 * MathUtil.java
 *
 * Created on 5 de Dezembro de 2004, 13:36
 */

package br.thejungle.util;

/**
 *
 * @author Fl�vio
 */
public class MathUtil {
    
    public static boolean isPointInCircle(long pointX, long pointY, long circleX, long circleY, long circleRadius) {
        double r = Math.sqrt((pointX-circleX)^2 + (pointY-circleY)^2);
        return (circleRadius>=r);
    }
    
}
