package br.thejungle.environment;

import java.io.Serializable;

/**
 * This is the developer of Species.
 */
public class Developer implements Serializable {

    private int developerID;

    private int name;

}
