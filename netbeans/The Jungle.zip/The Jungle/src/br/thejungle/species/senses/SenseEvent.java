package br.thejungle.species.senses;

import java.io.Serializable;

/**
 * This is an abstract class for all SenseEvents
 */
public abstract class SenseEvent implements Serializable {

}
